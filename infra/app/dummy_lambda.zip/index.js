exports.handler = async (event) => {
    // TODO implement
    return 'Hello from Lambda!';
};